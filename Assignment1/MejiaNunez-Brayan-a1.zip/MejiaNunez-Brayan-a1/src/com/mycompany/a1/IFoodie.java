package com.mycompany.a1;

public interface IFoodie {
	void setFoodConsumption(int rate);
}
